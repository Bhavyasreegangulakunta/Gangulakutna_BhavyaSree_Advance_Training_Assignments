package com.java7;

public class Student {

}
