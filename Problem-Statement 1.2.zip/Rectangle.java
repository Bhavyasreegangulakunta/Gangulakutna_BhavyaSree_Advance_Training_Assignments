package com.java1;
 class Rectangle
 
{ 
      int length; 
      int breadth; 
      //method to intialize length and breadth of rectangle 
      void setData(int l, int b) 
      {  
        length =l; 
        breadth=b; 
      } 
      //method to calculate area of rectangle 
      int area() 
      { 
        int rectArea; 
        rectArea = length * breadth; 
        return rectArea; 
      } 
} 
//Class to Create Rectangle Objects and Calculate Area
 class RectangleArea  
{ 
         public static void main(String[] args) 
     { 
           //Creating objects 
           Rectangle firstRect = new Rectangle(); 
           firstRect.setData(5,6); 
           int result = firstRect.area(); 
           System.out.println("Area of Rectangle = "+ result); 
     } 
}